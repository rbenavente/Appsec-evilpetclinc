[![Infrastructure Tests](https://www.bridgecrew.cloud/badges/github/rbenavente/evil.petclinic/general)](https://www.bridgecrew.cloud/link/badge?vcs=github&fullRepo=rbenavente%2Fevil.petclinic&benchmark=INFRASTRUCTURE+SECURITY)
[![Infrastructure Tests](https://www.bridgecrew.cloud/badges/github/rbenavente/evil.petclinic/cis_kubernetes)](https://www.bridgecrew.cloud/link/badge?vcs=github&fullRepo=rbenavente%2Fevil.petclinic&benchmark=CIS+KUBERNETES+V1.5)
[![Infrastructure Tests](https://www.bridgecrew.cloud/badges/github/rbenavente/evil.petclinic/pci_dss_v321)](https://www.bridgecrew.cloud/link/badge?vcs=github&fullRepo=rbenavente%2Fevil.petclinic&benchmark=PCI-DSS+V3.2.1)

PURPOSE
The purpose of this repository is to create a docker image that contains vulnerabilities to use during the container scanning RFS.
